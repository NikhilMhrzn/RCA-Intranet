from django.contrib import admin
from .models import Client_Assigned

# Register your models here.

class Client_AssignedAdmin(admin.ModelAdmin):
    list_display = ('Assigned_Client','Primary_Engineer','Secondary_Engineer','logo_preview') 
    autocomplete_fields = ['Primary_Engineer','Secondary_Engineer','Assigned_Client']
    list_per_page = 10
    ordering = ['Assigned_Client'] 
admin.site.register(Client_Assigned, Client_AssignedAdmin)