from django.apps import AppConfig


class AssignClientsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Assign_Clients'
