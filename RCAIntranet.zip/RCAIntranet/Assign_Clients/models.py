from django.db import models
from django.contrib.auth.models import  User
from clients.models import Client
from django.utils.html import mark_safe
from django.core.exceptions import ValidationError

# Create your models here.
class Client_Assigned(models.Model):
    id = models.BigAutoField(primary_key=True,unique=True)
    Primary_Engineer = models.ForeignKey(User, related_name='Primary_Engineer1',on_delete=models.CASCADE, limit_choices_to={'is_active': True},null=True)
    Secondary_Engineer = models.ForeignKey(User,related_name='Secondary_Engineer2',on_delete=models.CASCADE, limit_choices_to={'is_active': True},null=True)
    Assigned_Client = models.ForeignKey(Client,on_delete=models.CASCADE, limit_choices_to={'is_active': 'Active'})

    
    def __str__(self):
        return self.Assigned_Client.CompanyName
    
    def logo_preview(self): #new
        return mark_safe(f'<img src = "{self.Assigned_Client.Client_Logo.url}" width = "100"/>')
    
    def clean(self):
        if self.Primary_Engineer != None or self.Secondary_Engineer != None:
            if self.Primary_Engineer == self.Secondary_Engineer:
                raise ValidationError(("Primary and Secondary engineers must be different."))
  
        
    
    class Meta:
        db_table = 'Client_Assigned'
        verbose_name = 'Clients_Assign'
        verbose_name_plural = 'Clients_Assign'
        constraints = [
            models.UniqueConstraint(
                fields=["Primary_Engineer", "Secondary_Engineer","Assigned_Client"],
                name="Primary Engineer and Secondary Engineer must not be same",
            )
        ] 

