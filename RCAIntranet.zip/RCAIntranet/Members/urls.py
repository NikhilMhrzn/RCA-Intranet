from django.urls import path
from . import views


urlpatterns =[
    # path('',views.login),
    path('', views.login_User, name='login_user'),
    path('Dashboard', views.Dashboard, name='Dashboard'),
    path('logout',views.Logout,name='Logout')
]