from django.shortcuts import render,redirect
from django.contrib.auth import  login, authenticate, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages

# def login(request):
#     return render(request,'login.html')

def login_User(request):
    if request.method == 'POST':
        username = request.POST['UserName']
        password = request.POST['Password']

        user = authenticate(username=username,password=password)
        if user is not None:
            if user.is_active:
                login(request, user)
                return redirect('Dashboard')
            else:
                messages.info(request, 'The password is valid, but the account has been disabled!',extra_tags='danger')
                return redirect('login_user')
        else:
            messages.info(request, 'Invalid Username or Password',extra_tags='danger')
            return redirect('login_user')
    else:
        return render(request,'login.html')
    
@login_required(login_url='/')
def Dashboard(request):   
    return render(request, 'Dashboard.html')

@login_required(login_url='/')
def Logout(request):
     logout(request)
     messages.info(request, 'You have successfully logged out.',extra_tags='success')
     return redirect('login_user')
        