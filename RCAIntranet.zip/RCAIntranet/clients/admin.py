from django.contrib import admin
from .models import Client
# Register your models here.
class ClientAdmin(admin.ModelAdmin):
    # fieldsets = (
    #     ('Client Information', {
    #         'fields': (('CompanyName','AuditName'),('COE','is_active'))
    #     }),
    #     ('Logo', {
    #       'fields': (('Client_Logo', 'logo_preview'))
    #     }),
    # )

    fieldsets = [
        (
            'Client Information',
            {
                "fields": ["CompanyName", "AuditName", "COE", "is_active","Client_Logo"],
            },
        ),
        (
            "Advanced options",
            {
                "classes": ["collapse"],
                "fields": ["logo_preview"],
            },
        ),
    ]

    readonly_fields = ['logo_preview']    
    list_display = ('Company_Name', 'Audit_Name', 'COE', 'is_active','logo_preview') 
    list_per_page = 10
    search_fields = ['AuditName'] 
    ordering = ['AuditName'] 

admin.site.register(Client, ClientAdmin)