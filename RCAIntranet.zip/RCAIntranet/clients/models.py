from django.db import models
from django.utils.html import mark_safe

# Create your models here.

class Client(models.Model):
    id = models.BigAutoField(primary_key=True,unique=True)
    CompanyName = models.CharField(db_column='CompanyName', max_length=100, blank=False,unique=True)
    AuditName = models.CharField(db_column='AuditName',max_length=100,blank=False,unique=True)
    COE_Array = [
        ("Mass Merchant","Mass Merchant"),
        ("Specialty","Specialty"),
        ("Grocery","Grocery"),
    ]
    COE= models.CharField(db_column='COE',max_length=100, choices=COE_Array,blank=False)
    Active_Status = [
        ("Active","Active"),
        ("In-Active","In-Active"),
    ]
    is_active =  models.CharField(db_column='is_active',max_length=10, choices=Active_Status,blank=False)

    # PrimaryEngineer_Array =[
    #     ('1','Anish Rajbhandari'),
    #     ('2','Biky Shrestha'),
    # ]
    # Primary_Engineer = models.CharField(db_column='PrimaryEngineer',max_length=1000,choices=PrimaryEngineer_Array,blank=False)
    Client_Logo =  models.ImageField(upload_to ='uploads/ClientImage',blank=True,null=True , default='uploads/ClientImage/NoImage.jpg')
    Notes = models.TextField(db_column='note',max_length=1024,blank=True)

    def logo_preview(self): #new
        return mark_safe(f'<img src = "{self.Client_Logo.url}" width = "100"/>')
    
    @property
    def Company_Name(self):
        return self.CompanyName
    
    @property
    def Audit_Name(self):
        return self.AuditName
    
    def __str__(self):
        return self.CompanyName

    class Meta:
        db_table = 'Client_Information'
        verbose_name = 'RCA Clients'
        verbose_name_plural = 'RCA Clients'    
